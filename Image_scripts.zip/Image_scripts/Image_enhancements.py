#!/usr/bin/env python
# coding: utf-8

# In[1]:


from PIL import Image, ImageEnhance 
import cv2
import numpy as np
from matplotlib import pyplot as plt
import os


# In[2]:


def brightness(input_dir,output_dir,level):
    output_dire=output_dir +"brightness_" + str(level)
    os.chdir(input_dir)
    images=os.listdir(input_dir)
    os.mkdir(output_dire) 
    for img_name in images:
        im = Image.open(input_dir+"\\"+img_name)
        fname = output_dire+"\\"+img_name+".png"
        enhancer = ImageEnhance.Brightness(im)
        enhanced_im = enhancer.enhance(level)
        enhanced_im.save(fname)
        


# In[6]:


brightness(r"C:\Users\s8aar\multiview-net\DATA\DSC_9215",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",5)


# In[8]:


def contrast(input_dir,output_dir,level):
    output_dire=output_dir +"Contrast_" + str(level)
    os.chdir(input_dir)
    images=os.listdir(input_dir)
    os.mkdir(output_dire) 
    for img_name in images:
        im = Image.open(input_dir+"\\"+img_name)
        fname = output_dire+"\\"+img_name+".png"
        enhancer = ImageEnhance.Contrast(im)
        enhanced_im = enhancer.enhance(level)
        enhanced_im.save(fname)
        


# In[14]:


contrast(r"C:\Users\s8aar\multiview-net\DATA\KLE_1167",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",0.0)


# In[12]:


contrast(r"C:\Users\s8aar\multiview-net\DATA\DSC_9215",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",5)


# In[20]:


contrast(r"C:\Users\s8aar\multiview-net\DATA\KLE_1167",r"C:\Users\s8aar\multiview-net\DATA\datasets\\",2.0)


# In[2]:


def sharpness(input_dir,output_dir,level):
    output_dire=output_dir +"Sharpness_" + str(level)
    os.chdir(input_dir)
    images=os.listdir(input_dir)
    os.mkdir(output_dire) 
    for img_name in images:
        im = Image.open(input_dir+"\\"+img_name)
        fname = output_dire+"\\"+img_name+".png"
        enhancer = ImageEnhance.Sharpness(im)
        enhanced_im = enhancer.enhance(level)
        enhanced_im.save(fname)


# In[3]:


sharpness(r"C:\Users\s8aar\multiview-net\DATA\KLE_1167",r"C:\Users\s8aar\multiview-net\DATA\datasets\\",10.0)


# In[4]:


sharpness(r"C:\Users\s8aar\multiview-net\DATA\KLE_1167",r"C:\Users\s8aar\multiview-net\DATA\datasets\\",5.0)


# In[5]:


sharpness(r"C:\Users\s8aar\multiview-net\DATA\KLE_1167",r"C:\Users\s8aar\multiview-net\DATA\datasets\\",20.0)


# In[ ]:




