#!/usr/bin/env python
# coding: utf-8

# In[1]:


from __future__ import print_function
from builtins import input
import cv2 
import numpy as np
import os


# # ##The following code performs the operation g(i,j)=α⋅f(i,j)+β

# In[2]:


def addbrigcont(input_dir,output_dir,alpha,beta):
    output_dire=output_dir +"hist_alpha-" + str(alpha)+"_beta-"+str(beta)
    os.chdir(input_dir)
    images=os.listdir(input_dir)
    os.mkdir(output_dire)     
    for img_name in images:
        os.chdir(input_dir)
        image = cv2.imread(img_name)
        new_image = np.zeros(image.shape, image.dtype)
        fname=output_dire+"\\"+img_name+".png"
#         for y in range(image.shape[0]):
#             for x in range(image.shape[1]):
#                  for c in range(image.shape[2]):
#                         new_image[y,x,c] = np.clip(alpha*image[y,x,c] + beta, 0, 255)
        new_image = cv2.convertScaleAbs(image, alpha=alpha, beta=beta)
        RGB_img = cv2.cvtColor(new_image, cv2.COLOR_BGR2RGB)
        os.chdir(output_dire)
        cv2.imwrite(img_name+'.png',cv2.cvtColor(RGB_img, cv2.COLOR_RGB2BGR))
        


# In[3]:


addbrigcont(r"C:\Users\s8aar\multiview-net\DATA\KLE_2578",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",1.0,100.0)


# In[4]:


addbrigcont(r"C:\Users\s8aar\multiview-net\DATA\KLE_2578",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",1.0,130.0)


# In[5]:


addbrigcont(r"C:\Users\s8aar\multiview-net\DATA\KLE_2578",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",1.0,140.0)


# In[6]:


addbrigcont(r"C:\Users\s8aar\multiview-net\DATA\KLE_2578",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",2.0,80.0)


# In[7]:


addbrigcont(r"C:\Users\s8aar\multiview-net\DATA\KLE_2578",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",2.0,60.0)


# In[8]:


addbrigcont(r"C:\Users\s8aar\multiview-net\DATA\KLE_2578",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",3.0,10.0)


# In[9]:


addbrigcont(r"C:\Users\s8aar\multiview-net\DATA\KLE_2578",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",3.0,5.0)


# In[ ]:




