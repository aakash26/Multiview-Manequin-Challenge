#!/usr/bin/env python
# coding: utf-8

# In[9]:


import numpy as np
from matplotlib import pyplot as plt
import os
import skimage
import skimage.io
from skimage import data, exposure, img_as_float


# In[10]:


def skgamma(input_dir,output_dir,gamma):
    output_dire=output_dir +"SKlear_gamma_" + str(gamma)
    os.chdir(input_dir)
    images=os.listdir(input_dir)
    os.mkdir(output_dire) 
    for img_name in images:
        image = skimage.io.imread(input_dir+"\\"+img_name)
        gamma_corrected = exposure.adjust_gamma(image, gamma)
        fname=output_dire+"\\"+img_name+".png"
        skimage.io.imsave(fname,gamma_corrected)


# In[11]:


skgamma(r"C:\Users\s8aar\multiview-net\DATA\DSC_9215",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",1.0)


# In[18]:


skgamma(r"C:\Users\s8aar\multiview-net\DATA\DSC_9215",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",2.0)


# In[19]:


skgamma(r"C:\Users\s8aar\multiview-net\DATA\DSC_9215",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",0.5)


# In[16]:


skgamma(r"C:\Users\s8aar\multiview-net\DATA\DSC_9215",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",2.5)


# In[7]:


skgamma(r"C:\Users\s8aar\multiview-net\DATA\DSC_9215",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",1.5)


# In[23]:


skgamma(r"C:\Users\s8aar\multiview-net\DATA\DSC_9215",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",0.7)


# In[ ]:




