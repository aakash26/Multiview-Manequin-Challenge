#!/usr/bin/env python
# coding: utf-8

# In[2]:


import cv2
import numpy as np
from matplotlib import pyplot as plt
import os
import shutil
import skimage
import skimage.io
import skimage.filters
import matplotlib.pyplot as plt
from skimage.viewer import ImageViewer


# In[3]:


def deletedir(dir):
    shutil.rmtree(dir) 
    return


# In[6]:


def skblur(input_dir,output_dir,sigma):
    output_dire=output_dir +"blur_SKLEARN" + str(sigma)
    os.chdir(input_dir)
    images=os.listdir(input_dir)
    os.mkdir(output_dire) 
    for img_name in images:
        img = skimage.io.imread(input_dir+"\\"+img_name)
        blurred = skimage.filters.gaussian(img, sigma=(sigma,sigma), truncate=4.0, multichannel=True)
        fname=output_dire+"\\"+img_name+".png"
        skimage.io.imsave(fname,blurred)
    


# In[7]:


skblur(r"C:\Users\s8aar\multiview-net\DATA\pins1",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",0.0)


# In[5]:


skblur(r"C:\Users\s8aar\multiview-net\DATA\KLE_2578",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",1.0)


# In[6]:


skblur(r"C:\Users\s8aar\multiview-net\DATA\KLE_2578",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",2.0)


# In[7]:


skblur(r"C:\Users\s8aar\multiview-net\DATA\KLE_2578",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",3.0)


# In[8]:


skblur(r"C:\Users\s8aar\multiview-net\DATA\KLE_2578",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",4.0)


# In[9]:


skblur(r"C:\Users\s8aar\multiview-net\DATA\KLE_2578",r"C:\Users\s8aar\multiview-net\DATA\sythesized\\",5.0)


# In[19]:


def plotnoise(input_dir, mode, output_dir):
    output_dire=output_dir +"Noise_" + mode
    os.chdir(input_dir)
    images=os.listdir(input_dir)
    os.mkdir(output_dire)
    for img_name in images:
        img = skimage.io.imread(input_dir+"\\"+img_name)
        gimg = skimage.util.random_noise(img, mode=mode)
        fname=output_dire+"\\"+img_name+".png"
        skimage.io.imsave(fname,gimg)
plotnoise(r"C:\Users\s8aar\multiview-net\DATA\KLE_1790", "gaussian" ,r"C:\Users\s8aar\multiview-net\DATA\sythesized\\")
plotnoise(r"C:\Users\s8aar\multiview-net\DATA\KLE_1790", "s&p" ,r"C:\Users\s8aar\multiview-net\DATA\sythesized\\")


# In[6]:


import skimage.io
import matplotlib.pyplot as plt
img_path=r"C:\Users\s8aar\multiview-net\DATA\KLE_1167\KLE_1167_2.png"
img = skimage.io.imread(img_path)/255.0

def plotnoise(img, mode, r, c, i,directory):
    os.chdir(directory)
    images=os.listdir(directory)
    os.mkdir(output_dir+'\Noise_'+mode) 
    plt.subplot(r,c,i)
    if mode is not None:
        gimg = skimage.util.random_noise(img, mode=mode)
        plt.imshow(gimg)
    else:
        plt.imshow(img)
    plt.title(mode)
    fname=img_path+"noise_"+mode+".jpg"
    skimage.io.imsave(fname,gimg)
    plt.axis("off")

plt.figure(figsize=(18,24))
r=4
c=2
plotnoise(img, "gaussian", r,c,1)
plotnoise(img, "localvar", r,c,2)
plotnoise(img, "poisson", r,c,3)
plotnoise(img, "salt", r,c,4)
plotnoise(img, "pepper", r,c,5)
plotnoise(img, "s&p", r,c,6)
plotnoise(img, "speckle", r,c,7)
plt.show()


# In[ ]:




